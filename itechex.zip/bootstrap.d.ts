declare module 'bootstrap/dist/js/bootstrap' {
    const bootstrap: any;
    export default bootstrap;
  }
  