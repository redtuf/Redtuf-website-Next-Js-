"use strict";
exports.id = 9598;
exports.ids = [9598];
exports.modules = {

/***/ 9598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ rtl_Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/rtl/Mobilemenu.tsx




const Mobilemenu = ()=>{
    const openMobileMenu = ()=>{
        document.body.classList.toggle("mobile-menu--toggle");
    };
    const [activeMenu, setActiveMenu] = (0,external_react_.useState)("");
    const clickHandler = (e)=>{
        if (activeMenu === e.target.innerHTML) {
            setActiveMenu("");
        } else {
            setActiveMenu(e.target.innerHTML);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "mobile-menu",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mobile-menu__head",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/rtl",
                        className: "mobile-menu__logo",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/logo-light.png",
                            alt: "image",
                            className: "mobile-menu__logo-img"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "mobile-menu__close",
                        onClick: openMobileMenu,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "material-symbols-rounded mat-icon fw-300",
                            children: [
                                " ",
                                "close",
                                " "
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mobile-menu__body",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-menu__start",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mobile-menu__info mt-auto",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "clr-neutral mb-2",
                                    children: "Get in touch"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "list mobile-menu__info-list",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mobile-menu__info-text",
                                                children: " +880 12345678 "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mobile-menu__info-text",
                                                children: " demo@mail.com "
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "mobile-menu__info-text",
                                                children: [
                                                    " ",
                                                    "62 Wakehurst Street Bakersfield",
                                                    " "
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-menu__center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list mobile-menu__list",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: `${activeMenu == "بيت" && "is-active"}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            className: "mobile-menu__link has-sub",
                                            onClick: clickHandler,
                                            children: "بيت"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: `list mobile-menu__sub ${activeMenu == "بيت" && "d-block"}`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "/rtl",
                                                        className: "mobile-menu__sub-link",
                                                        onClick: openMobileMenu,
                                                        children: [
                                                            " ",
                                                            "بيت 1",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "/rtl/home-2",
                                                        className: "mobile-menu__sub-link",
                                                        onClick: openMobileMenu,
                                                        children: [
                                                            " ",
                                                            "بيت 2",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "/rtl/home-3",
                                                        className: "mobile-menu__sub-link",
                                                        onClick: openMobileMenu,
                                                        children: [
                                                            " ",
                                                            "بيت 3",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        href: "/rtl/home-4",
                                                        className: "mobile-menu__sub-link",
                                                        onClick: openMobileMenu,
                                                        children: [
                                                            " ",
                                                            "بيت 4",
                                                            " "
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: `${activeMenu == "مدونة" && "is-active"}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            onClick: clickHandler,
                                            className: "mobile-menu__link has-sub",
                                            children: "مدونة"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: `list mobile-menu__sub ${activeMenu == "مدونة" && "d-block"}`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/blog-page-1",
                                                        className: "mobile-menu__sub-link",
                                                        children: [
                                                            " ",
                                                            "صفحة المدونة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/blog-details-1",
                                                        className: "mobile-menu__sub-link",
                                                        children: [
                                                            " ",
                                                            "تفاصيل المدونة",
                                                            " "
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: `${activeMenu == "خدمة" && "is-active"}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            onClick: clickHandler,
                                            className: "mobile-menu__link has-sub",
                                            children: "خدمة"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: `list mobile-menu__sub ${activeMenu == "خدمة" && "d-block"}`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/service-1",
                                                        className: "mobile-menu__sub-link",
                                                        children: [
                                                            " ",
                                                            "صفحة الخدمة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/service-details-1",
                                                        className: "mobile-menu__sub-link",
                                                        children: [
                                                            " ",
                                                            "تفاصيل الخدمة",
                                                            " "
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        onClick: openMobileMenu,
                                        href: "/rtl/contact-us-1",
                                        className: "mobile-menu__link",
                                        children: [
                                            " ",
                                            "اتصل بنا",
                                            " "
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: `${activeMenu == "الصفحات" && "is-active"}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            onClick: clickHandler,
                                            className: "mobile-menu__link has-sub",
                                            children: "الصفحات"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: `list mobile-menu__sub ${activeMenu == "الصفحات" && "d-block"}`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/about-us-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "معلومات عنا",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/choose-us-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "لماذا أخترتنا",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/case-study-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "دراسة الحالة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/facts-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "التاريخ والحقائق",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/faq-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "التعليمات",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/help-center",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "مركز المساعدة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/getting-started",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "ابدء",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/help-center-details",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "تفاصيل مركز المساعدة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/case-study-details-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "تفاصيل دراسة الحالة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/leadership",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "صفحة القيادة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/leadership-page",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "تفاصيل القيادة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/referral",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "الإحالة",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/pricing-plan-1",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "خطة التسعير",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/error",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "خطأ",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/coming-soon",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "قريباً",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        onClick: openMobileMenu,
                                                        href: "/rtl/terms-condition",
                                                        className: "mobile-menu__deep-link",
                                                        children: [
                                                            " ",
                                                            "الشروط والأحكام",
                                                            " "
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mobile-menu__end",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "search-bar pill",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        className: "search-bar__input",
                                        placeholder: "Search keyword"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "search-bar__btn",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "material-symbols-rounded mat-icon fw-200",
                                            children: [
                                                " ",
                                                "search",
                                                " "
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list mt-6",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "mobile-notification",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mobile-notification__icon mobile-notification__icon-primary",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "material-symbols-rounded mat-icon",
                                                        children: [
                                                            " ",
                                                            "mark_email_unread",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "mobile-notification__content",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__title",
                                                            children: [
                                                                " ",
                                                                "تم استلام رسالة جديدة",
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__subtitle",
                                                            children: [
                                                                " ",
                                                                "تحدثنا عن مشروع في الرسالة",
                                                                " "
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "mobile-notification",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mobile-notification__icon mobile-notification__icon-secondary",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "material-symbols-rounded mat-icon",
                                                        children: [
                                                            " ",
                                                            "tips_and_updates",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "mobile-notification__content",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__title",
                                                            children: [
                                                                " ",
                                                                "تثبيت التحديثات",
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__subtitle",
                                                            children: [
                                                                " ",
                                                                "تم إصدار إصدار جديد ، قم بالتثبيت الآن!",
                                                                " "
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "mobile-notification",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mobile-notification__icon mobile-notification__icon-success",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "material-symbols-rounded mat-icon",
                                                        children: [
                                                            " ",
                                                            "add_photo_alternate",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "mobile-notification__content",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__title",
                                                            children: [
                                                                " ",
                                                                "تم إصدار موضوع جديد",
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__subtitle",
                                                            children: [
                                                                " ",
                                                                "تم إصدار نمط موضوع جديد ، قم بالتثبيت الآن!",
                                                                " "
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "mobile-notification",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mobile-notification__icon mobile-notification__icon-warning",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "material-symbols-rounded mat-icon",
                                                        children: [
                                                            " ",
                                                            "account_balance_wallet",
                                                            " "
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "mobile-notification__content",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__title",
                                                            children: [
                                                                " ",
                                                                "تم استلام الدفعة",
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "mobile-notification__subtitle",
                                                            children: [
                                                                " ",
                                                                "$٥۰۰ تم استلام الدفعة",
                                                                " "
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list list--sm mt-auto",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "social-menu social-menu--light",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__icon",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookF, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__text",
                                                    children: "فيسبوك"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "social-menu social-menu--light",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__icon",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__text",
                                                    children: "تويتر"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "social-menu social-menu--light",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__icon",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaInstagram, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__text",
                                                    children: "الانستغرام"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "social-menu social-menu--light",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__icon",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaLinkedinIn, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__text",
                                                    children: "ينكدين"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "social-menu social-menu--light",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__icon",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaDribbble, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "social-menu__text",
                                                    children: "لعابه"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const rtl_Mobilemenu = (Mobilemenu);

// EXTERNAL MODULE: external "next-themes"
var external_next_themes_ = __webpack_require__(1162);
;// CONCATENATED MODULE: ./components/rtl/Navbar.tsx






const Navbar = ({ ltrurl  })=>{
    const [mounted, setMounted] = (0,external_react_.useState)(false);
    const { theme , setTheme  } = (0,external_next_themes_.useTheme)();
    const inactiveTheme = theme === "light" ? "dark" : "light";
    const openMobileMenu = ()=>{
        document.body.classList.toggle("mobile-menu--toggle");
    };
    (0,external_react_.useEffect)(()=>{
        setMounted(true);
    }, []);
    if (!mounted) {
        return null;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(rtl_Mobilemenu, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "header-top-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list list-row flex-wrap list--divider align-items-center justify-content-center justify-content-lg-start",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "t-link group group-row group-xs align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "icon-box icon-box--xs circle bg-neutral-300",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "material-symbols-rounded mat-icon size-20 fw-300 lh-1 clr-base",
                                                        children: " mail "
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "d-none d-xl-inline-block clr-heading",
                                                    children: " @ البريد التجريبي "
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "t-link group group-row group-xs align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "icon-box icon-box--xs circle bg-neutral-300",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "material-symbols-rounded mat-icon size-20 fw-300 lh-1 clr-base",
                                                        children: " phone_in_talk "
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "d-none d-xl-inline-block clr-heading",
                                                    children: " +۷ (۹۰۳) ۸۸۰-۹۱-۸٥ "
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "t-be-md-0",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "t-link group group-row group-xs align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "icon-box icon-box--xs circle bg-neutral-300",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "material-symbols-rounded mat-icon size-20 fw-300 lh-1 clr-base",
                                                        children: " location_pin "
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "d-none d-xl-inline-block clr-heading",
                                                    children: " سانتا آنا ، إلينوي ۸٥٤۸٦ "
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "ms-md-auto",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "#",
                                            className: "t-link group group-row group-xs align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "icon-box icon-box--xs circle bg-neutral-300",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "material-symbols-rounded mat-icon size-20 fw-300 lh-1 clr-base",
                                                        children: " alarm "
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "d-none d-xl-inline-block clr-heading",
                                                    children: " ۰۸:۰۰ صباحًا - ٦:۰۰ مساءً "
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "d-none d-md-block",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list list-xs list-row",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: "t-link social-icon social-icon--xs clr-heading :clr-base lg-text",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookF, {})
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: "t-link social-icon social-icon--xs clr-heading :clr-base lg-text",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {})
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: "t-link social-icon social-icon--xs clr-heading :clr-base lg-text",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaInstagram, {})
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "#",
                                                        className: "t-link social-icon social-icon--xs clr-heading :clr-base lg-text",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaLinkedinIn, {})
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: "header header--2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-12",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "mobile-header",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "container",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "row",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "col-12",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mobile-header__content",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                            href: "/rtl",
                                                            className: "logo",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                    src: "/images/logo.png",
                                                                    alt: "image",
                                                                    className: "logo__img logo__dark"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                    src: "/images/logo-light.png",
                                                                    alt: "image",
                                                                    className: "logo__img logo__light"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            onClick: openMobileMenu,
                                                            className: "bttn bttn--sqr bttn--sqr-sm bttn--light bttn--rounded mobile-menu__toggler",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "material-symbols-rounded mat-icon fw-300",
                                                                children: " menu "
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                                    className: "primary-menu align-items-center",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                            href: "/rtl",
                                            className: "logo",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/images/logo.png",
                                                    alt: "image",
                                                    className: "logo__img logo__dark"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: "/images/logo-light.png",
                                                    alt: "image",
                                                    className: "logo__img logo__light"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list primary-menu__list",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            className: "primary-menu__link has-sub",
                                                            children: " بيت "
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "list sub-menu",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "/rtl",
                                                                        className: "sub-menu__link",
                                                                        children: " بيت ۱ "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "/rtl/home-2",
                                                                        className: "sub-menu__link",
                                                                        children: " بيت ۲ "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "/rtl/home-3",
                                                                        className: "sub-menu__link",
                                                                        children: " بيت ۳ "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "/rtl/home-4",
                                                                        className: "sub-menu__link",
                                                                        children: " بيت ٤ "
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            className: "primary-menu__link has-sub",
                                                            children: " مدونة "
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "list sub-menu",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "blog-page-1",
                                                                        className: "sub-menu__link",
                                                                        children: " صفحة المدونة "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "blog-details-1",
                                                                        className: "sub-menu__link",
                                                                        children: " تفاصيل المدونة "
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            className: "primary-menu__link has-sub",
                                                            children: " خدمة "
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "list sub-menu",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "service-1",
                                                                        className: "sub-menu__link",
                                                                        children: " صفحة الخدمة "
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                        href: "service-details-1",
                                                                        className: "sub-menu__link",
                                                                        children: " تفاصيل الخدمة "
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "contact-us-1",
                                                        className: "primary-menu__link",
                                                        children: " اتصل بنا "
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    className: "mega-menu--container",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            href: "#",
                                                            className: "primary-menu__link has-megamenu",
                                                            children: " الصفحات "
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                            className: "list mega-menu",
                                                            children: [
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "mega-menu__title",
                                                                            children: "تفاصيل المعلومات"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "list mega-menu__list",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "about-us-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " معلومات عنا "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "choose-us-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " لماذا أخترتنا "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "case-study-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " دراسة الحالة "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "facts-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " التاريخ والحقائق "
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "mega-menu__title",
                                                                            children: "ساعد لدعم"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "list mega-menu__list",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "faq-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " التعليمات "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "help-center",
                                                                                        className: "mega-menu__link",
                                                                                        children: " مركز المساعدة "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "getting-started",
                                                                                        className: "mega-menu__link",
                                                                                        children: " ابدء "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "help-center-details",
                                                                                        className: "mega-menu__link",
                                                                                        children: " تفاصيل مركز المساعدة "
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "mega-menu__title",
                                                                            children: "دعونا نتواصل"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "list mega-menu__list",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "case-study-details-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " تفاصيل دراسة الحالة "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "leadership",
                                                                                        className: "mega-menu__link",
                                                                                        children: " صفحة القيادة "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "leadership-page",
                                                                                        className: "mega-menu__link",
                                                                                        children: " تفاصيل القيادة "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "referral",
                                                                                        className: "mega-menu__link",
                                                                                        children: " الإحالة "
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            className: "mega-menu__title",
                                                                            children: "صفحات أخرى"
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                                            className: "list mega-menu__list",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "pricing-plan-1",
                                                                                        className: "mega-menu__link",
                                                                                        children: " خطة التسعير "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "error",
                                                                                        className: "mega-menu__link",
                                                                                        children: " خطأ "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "coming-soon",
                                                                                        className: "mega-menu__link",
                                                                                        children: " قريباً "
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                                        href: "terms-condition",
                                                                                        className: "mega-menu__link",
                                                                                        children: " الشروط والأحكام "
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    className: "ms-auto",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: ltrurl,
                                                        className: "primary-menu__link",
                                                        children: "LTR"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "dark-mode-toggle",
                                                        onClick: ()=>setTheme(inactiveTheme),
                                                        children: theme != "light" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "dark-mode-toggle__light",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "material-symbols-rounded mat-icon",
                                                                children: [
                                                                    " ",
                                                                    "light_mode",
                                                                    " "
                                                                ]
                                                            })
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "dark-mode-toggle__dark",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                                className: "material-symbols-rounded mat-icon",
                                                                children: [
                                                                    " ",
                                                                    "dark_mode",
                                                                    " "
                                                                ]
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "pricing-plan-1",
                                                        className: "bttn bttn--base bttn-sm bttn-pill fw-md flex-shrink-0",
                                                        children: " إقتباس حر "
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const rtl_Navbar = (Navbar);


/***/ })

};
;